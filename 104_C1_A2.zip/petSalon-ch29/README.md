# petSalon-ch29
In this project we create a pet salon using object literal, object constructor
